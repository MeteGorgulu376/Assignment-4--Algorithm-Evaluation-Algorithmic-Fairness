# Data

Put these three files in this folder before running the notebook. They are not committed to the repository.

| File | Dataset | Download |
|---|---|---|
| `adult.csv` | UCI Adult (training file, 32,561 rows) | https://www.kaggle.com/datasets/uciml/adult-census-income |
| `german.data` | UCI Statlog German Credit (1,000 rows, space-separated) | https://archive.ics.uci.edu/dataset/144 |
| `propublica_data_for_fairml.csv` | ProPublica COMPAS two-year data, FairML subset (6,172 rows) | https://www.kaggle.com/danofer/compass |

In Google Colab you don't need this folder: the notebook asks you to upload the files, or the zip archives that contain them.
